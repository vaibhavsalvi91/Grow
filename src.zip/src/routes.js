
import Dashboard from "./views/Dashboard.js";
import Login from "./views/Login.js";

const dashboardRoutes = [
  {
    path: "/Dashboard",
    name: "Dashboard",
    component: Dashboard,
    layout: "/admin",
  },
  {
    path: "/Login",
    name: "Login",
    component: Login,
    layout: "/admin",
  },
];

export default dashboardRoutes;
