import React from 'react'
import {useLocation, NavLink} from 'react-router-dom';

import "./sidebar.scss";

const Sidebar = ({ routes }) => {
    const location = useLocation();
    const activeRoute = (routeName) => {
        return location.pathname.indexOf(routeName) > -1 ? "active" : "";
    };
    return(
        <div className="sidebar_cont sidebar-responsive" id="sidebar">
            <div className="sidebarinner_cont">
                    <ul className="sidebar_menu">
                        {routes.map((prop, key) => {
                                if (!prop.redirect)
                                return (
                                    <li
                                    className={
                                        prop.upgrade
                                        ? "active active-pro"
                                        : activeRoute(prop.layout + prop.path), "menu-item"
                                    }
                                    key={key}
                                    >
                                    <NavLink
                                        to={prop.layout + prop.path}
                                        className="nav-link"
                                        activeClassName="active"
                                    >
                                        <i className={prop.icon} />
                                        <img src={prop.imgpath} />
                                        <span>{prop.name}</span>
                                    </NavLink>
                                    </li>
                                );
                                return null;
                            })}
                    </ul>
            </div>
        </div>
    )
}
export default Sidebar;