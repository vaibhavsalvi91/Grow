import {useState} from 'react';
import { Button} from 'react-bootstrap';



import "./Navbar.scss";
import logo from "../../assets/logo.png";
import profileimg from "../../assets/profile-small.png";
import gridviewblack from "../../assets/grid-view.png";
import gridviewwhite from "../../assets/grid-view-white.png";
/*logos*/
import slacklogo from "../../assets/slack-large.png";
import asanalogo from "../../assets/asana-large.png";
import basecamplogo from "../../assets/basecamp-large.png";
import clickuplogo from "../../assets/clickup-large.png";
import skypelogo from "../../assets/skype-large.png";

const Navbar = () => {

    const mobileSidebarToggle = (e) => {
        e.preventDefault();
        document.documentElement.classList.toggle("nav-open");
        var node = document.createElement("div");
        node.id = "bodyClick";
        node.onclick = function () {
          this.parentElement.removeChild(this);
          document.documentElement.classList.toggle("nav-open");

        };
        document.body.appendChild(node);
    };

    const [isActive, setActive] = useState(false);
    const clickTogg = () => {
        setActive(!isActive);
    }

    const useEffect = () => {
        document.body.classList.toggle('blacktheme');
    }
    
    const [sidebarOpen, setSidebarOpen] =  useState(false);

    const openSidebar = () => {
        setSidebarOpen(true);
    }

    const closeSidebar = () => {
        setSidebarOpen(false);
    }
    
    return (
         
        <div className="navbar top_header">
            <div className="nav-icon">
               <a onClick={useEffect}><img src={logo}  alt="logo" /></a> 
            </div>
            
            
            <ul className="navbar_right">
                <li className="main_heading mr-auto">
                <Button id="menumobileclick"
                        variant="dark"
                        className="d-lg-none btn-fill d-flex justify-content-center align-items-center rounded-circle p-2"
                        onClick={mobileSidebarToggle}
                    >
                        <i className="fa fa-navicon"></i>
                    </Button>
                    <a href="#"><span>Dashboard</span></a>
                </li>
                <li className="notification">
                    <a href="#"><i className="icon icon-notification"></i></a>
                    <ul className="submenu">
                        <li><a href="#">Notification 1</a></li>
                        <li><a href="#">Notification 2</a></li>
                        <li><a href="#">Notification 3</a></li>
                        <li><a href="#">Notification 4</a></li>
                        <li><a href="#">Notification 5</a></li>
                    </ul>
                </li>
                <li className="gridview">
                    <a href="#">
                        <img className="gridviewblack" src={gridviewblack} width="20" alt="gridview" />
                        <img className="gridviewwhite" src={gridviewwhite} width="20" alt="gridview" />
                        <ul className="submenu">
                            <li>
                                <a href="#">
                                    <img src={slacklogo} alt="slack" />
                                    <span>Slack</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <img src={asanalogo} alt="slack" />
                                    <span>Asana</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <img src={basecamplogo} alt="slack" />
                                    <span>Basecamp</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <img src={clickuplogo} alt="slack" />
                                    <span>Clickup</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <img src={skypelogo} alt="slack" />
                                    <span>Skype</span>
                                </a>
                            </li>
                        </ul>
                    </a>
                </li>
                <li className="user_cont">
                    <a href="#" ><img src={profileimg} alt="profile_img" />
                        <i className="fa fa-angle-down"></i>
                    </a>
                    <ul className="submenu">
                        <li><a href="#">Profile</a></li>
                        <li><a href="#">Setting</a></li>
                        <li><a href="#">Logout</a></li>
                    </ul>
                </li>
                
            </ul>
        </div>
         
         
    )
    
}
export default Navbar;