
import React from "react";


import Login from "../../views/Login";


function Admin() {
  
  


  
  
  return (
      <Login />
  );
}

export default Admin;
