import React from 'react';
import { Route, Switch } from "react-router-dom";

import Sidebar from "../components/sidebar/sidebar.js";
import Navbar from "../components/navbar/Navbar.js";
import routes from "../routes.js";

const Dashboard = () => {
  const mainPanel = React.useRef(null);
  const getRoutes = (routes) => {
    return routes.map((prop, key) => {
      if (prop.layout === "/admin/Login") {
        return (
          <Route
            path={prop.layout + prop.path}
            render={(props) => <prop.component {...props} />}
            key={key}
          />

        );
      } else {
        return null;
      }
    });
  };
    return (
      <div className="wrapper">
        <Navbar />
        <Sidebar routes={routes} />
        <div className="main-panel" ref={mainPanel}>
            <Switch>
              {getRoutes(routes)}
            
            </Switch>
        </div>
      </div>
    )
}
export default Dashboard;