import React from 'react';
import { Button } from 'react-bootstrap';
import { Link } from "react-router-dom";
import growlogo from "../assets/grow-logo.png";
import loginbg from "../assets/loginbg.jpg";

const Login = () => {
    return (
      <div className="login_container">
        <div className="loginleft_cont">
          <div className="loginform_cont">
            <div className="proheading">
              <abbr>Gr<img src={growlogo} alt="growlogo" />w</abbr>
              <span>The Digital Forest</span>
            </div>
          <h1 className="section_heading">Sign in</h1>
          <ul className="login_form">
            <li>
              <input type="text" placeholder="Username" />
            </li>
            <li>
              <input type="password" placeholder="Password" />
            </li>
            <li>
              <Button className="forget_btn">Forget Password?</Button>
            </li>
            <li>
              <Link className="signin_btn" to="./Dashboard">Sign in</Link>
            </li>
          </ul>
          </div>
        </div>
        <div className="loginright_cont">
            <img src={loginbg} alt="loginbg" />
        </div>
      </div>
    )
}
export default Login;