import React from 'react';
import { BrowserRouter, Route, Switch, Redirect } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';

import AdminLayout from '../src/components/layouts/Admin.js';

const App = () => {
  return (
    <>
    <BrowserRouter>
      <Switch>
        <Route path="/admin" render={(props) => <AdminLayout {...props} />} />
        <Redirect from="/" to="/admin/Login" />
      </Switch>
    </BrowserRouter>
   </>
  );
}

export default App;
